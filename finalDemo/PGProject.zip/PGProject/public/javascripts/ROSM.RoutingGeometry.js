
ROSM.RoutingGeometry = {
  show: function(response) {
    ROSM.G.route.showRoute(response);
  }
}

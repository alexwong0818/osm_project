
ROSM.init = function() {
  ROSM.Map.init();
  ROSM.Routing.init();
  ROSM.GUI.init();
  ROSM.POI.init();
};

ROSM.init();

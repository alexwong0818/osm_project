declare type Transferable = ArrayBuffer | MessagePort | ImageBitmap;

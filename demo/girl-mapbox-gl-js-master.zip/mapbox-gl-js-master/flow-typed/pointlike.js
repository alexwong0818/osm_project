import type Point from '@mapbox/point-geometry';
declare type PointLike = Point | [number, number];

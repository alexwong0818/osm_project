// @flow

/* eslint-env browser */
module.exports = (self: Window);

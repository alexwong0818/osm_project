
module.exports = require('./v8.json');
